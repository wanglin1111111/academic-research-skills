# low-cost-search

低成本高精度搜索引擎。三层缓存 + 意图路由 + DuckDuckGo 搜索，模型常驻内存，缓存命中响应 **< 500ms**。

---

## 🚀 零配置使用（推荐）

**无需手动启动服务！** 首次搜索时自动启动，用户零感知。

```python
from search_client import search

# 首次调用会自动启动服务（约 10 秒）
result = search("武汉有哪些有名旅游景点")

# 后续调用直接返回（缓存命中 < 50ms）
result = search("武汉有哪些有名旅游景点")  # 快！
```

### 手动启动（可选）

如果希望提前预热服务：

| 方式 | 命令 |
|------|------|
| 双击启动 | `start_server.bat` |
| 静默启动 | `start_server_silent.vbs` |
| 命令行 | `python scripts/search_server.py --warmup` |

---

## 快速测试

```bash
# 测试脚本
test_search.bat

# 快速搜索
quick_search.bat "武汉景点"
```

---

## 核心架构

```
┌─────────────────────────────────────────────────────┐
│  search_server.py  (后台常驻进程，端口 18765)         │
│  模型预加载，缓存常驻，HTTP 接口                      │
└──────────────────────┬──────────────────────────────┘
                       │ localhost HTTP POST /search
                       ▼
                User Query
                       │
          ┌─────────────┴──────────────┐
          ▼                          ▼
    L3 Raw Hit                  L2 Semantic Hit
    (normalized match)          (cosine ≥ 0.85)
    < 30ms                       < 500ms
          │                          │
          └──────────┬───────────────┘
                     │ miss
                     ▼
             DuckDuckGo Search
             ~15-40s (网络延迟)
```

---

## 启动 server（命令行）

```bash
# 启动并 warmup 模型（~8s，之后所有搜索秒回）
python scripts/search_server.py --warmup --port 18765

# 后台运行（模型懒加载，首次搜索时才 warmup）
python scripts/search_server.py --port 18765
```

---

## 调用方式

### HTTP 调用（推荐）

```python
import urllib.request, json

req = urllib.request.Request(
    "http://127.0.0.1:18765/search",
    data=json.dumps({"query": "Python list comprehension 教程", "max_results": 5}).encode(),
    headers={"Content-Type": "application/json"},
    method="POST",
)
with urllib.request.urlopen(req, timeout=60) as resp:
    data = json.loads(resp.read())
    for r in data["results"]:
        print(r["title"], r["url"])
```

### PowerShell

```powershell
$body = @{ query = "python defaultdict"; max_results = 3 } | ConvertTo-Json
$r = Invoke-WebRequest -Uri "http://127.0.0.1:18765/search" -Method POST -Body $body -ContentType "application/json" -TimeoutSec 60
$d = $r.Content | ConvertFrom-Json
$d.results | ForEach-Object { Write-Host $_.title }
```

### CLI subprocess（兼容模式）

```bash
python scripts/search.py "python list comprehension" --max 5
```
Fallback：server 不可用时自动降级到 subprocess。

---

## 文件结构

```
low-cost-search/
├── SKILL.md
├── scripts/
│   ├── search_server.py   # 常驻 HTTP 服务（后台运行）
│   ├── search_client.py   # Python HTTP 客户端 + subprocess fallback
│   ├── search.py          # CLI 入口（subprocess 模式）
│   └── cache.py           # 三层缓存核心
└── references/
    └── cache/
        ├── l2_semantic.jsonl   # L2 语义缓存
        └── l3_raw.jsonl        # L3 精确缓存
```

---

## 性能数据

| 场景 | 冷启动 | 常驻后 |
|---|---|---|
| 首次 query（无缓存） | ~40s（网络搜索） | — |
| 完全重复 query | **28ms** | **L3 hit** |
| 语义改写 query | **435ms** | **L2 hit (sim=0.93)** |
| 模型 warmup | ~8s（仅一次） | — |

---

## 输出 JSON

```json
{
  "query": "python defaultdict example",
  "intent": "code",
  "cache_hit": true,
  "cache_tier": "L2_semantic",
  "results": [
    {
      "title": "python-defaultdict of defaultdict?",
      "url": "https://stackoverflow.com/questions/...",
      "snippet": "...",
      "source": "stackoverflow"
    }
  ],
  "search_ms": 435,
  "total_raw": 5,
  "trusted_count": 2
}
```

---

## 三层缓存

| 层 | 原理 | 延迟 | 命中率估算 |
|---|---|---|---|
| **L3** | Normalized query 精确匹配 | **< 30ms** | ~15% |
| **L2** | Embedding cosine ≥ 0.85 | **< 500ms** | ~20% |
| **L1** | 进程内 LRU（server 常驻后无效） | < 1ms | — |

---

## 健康检查

```bash
curl http://127.0.0.1:18765/health
# → ok
```

---

## 依赖

- `sentence-transformers>=2.0` — all-MiniLM-L6-v2（首次 warmup 后常驻）
- `ddgs>=9.0` — DuckDuckGo 多引擎搜索
- Python 3.10+
- 网络：`hf-mirror.com`、`duckduckgo.com`
